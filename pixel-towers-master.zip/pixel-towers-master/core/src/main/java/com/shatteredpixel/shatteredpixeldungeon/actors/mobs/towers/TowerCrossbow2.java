package com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers;
import com.shatteredpixel.shatteredpixeldungeon.sprites.TowerCrossbow2Sprite;

public class TowerCrossbow2 extends TowerCrossbow1{
    {
        HP = HT = 55;
        spriteClass = TowerCrossbow2Sprite.class;

        viewDistance = 8;

        baseAttackDelay = 0.7f;

        upgradeLevel = 10;

        cost = 450;
        upgrade1Cost = 550;
        damageMin = 3;
        damageMax = 8;
    }
}
