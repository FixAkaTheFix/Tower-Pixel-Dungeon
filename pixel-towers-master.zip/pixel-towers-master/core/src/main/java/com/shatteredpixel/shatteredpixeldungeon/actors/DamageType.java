package com.shatteredpixel.shatteredpixeldungeon.actors;

public enum DamageType {
    PHYSICAL,
    MAGICAL,
    ELEMENTAL,
    LIGHTNING,
    ICE,
    FIRE,
    SHIELDIGNORING,
    PROJECTILE,
    POISON,
    PURE
}
