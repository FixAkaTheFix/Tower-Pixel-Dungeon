package com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers;


import com.shatteredpixel.shatteredpixeldungeon.sprites.TowerCannon2Sprite;


public class TowerCannon2 extends TowerCannon1{

    {
        HP = HT = 60;
        spriteClass = TowerCannon2Sprite.class;

        viewDistance = 6;//DPT =15*0.66 = 10;DPT/C=10:450=0.02222
        baseAttackDelay = 1.5f;

        upgradeLevel = 10;

        cost = 600;
        upgrade1Cost = 700;
        damageMin = 2;
        damageMax = 12;
        damageExplosionMult = 0.5f;
    }
}
