package com.shatteredpixel.shatteredpixeldungeon.actors.mobs;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Blindness;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Charm;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Paralysis;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ShinobiSprite;
import com.watabou.utils.Bundle;
import com.watabou.utils.PathFinder;
import com.watabou.utils.Random;

import java.util.ArrayList;

public class Shinobi extends Mob {

	private int teleportCooldown = 0;

	{
		spriteClass = ShinobiSprite.class;

		HP = HT = 80;
		defenseSkill = 8;
		viewDistance = 5;
		EXP = 7;

		immunities.add( Paralysis.class );
		immunities.add( Charm.class );
		immunities.add( Blindness.class );
	}

	@Override
	public int damageRoll() {
		return Random.NormalIntRange( 5, 14 );
	}

	@Override
	protected boolean canAttack( Char enemy ) {
		Ballistica attack = new Ballistica( pos, enemy.pos, Ballistica.PROJECTILE);
		return attack.collisionPos == enemy.pos;
	}
	
	@Override
	protected boolean getCloser( int target ) {
		if (fieldOfView[target] && Dungeon.level.distance( pos, target ) <= 3 && teleportCooldown <= 0) {
			teleport( );
			spend( -1 / speed() );
			return true;
		} else {
			teleportCooldown--;
			return super.getCloser( target );
		}
	}

	@Override
	public float attackDelay() {
		return super.attackDelay() * 0.6f;
	}

	private void teleport() {

		int direction = PathFinder.NEIGHBOURS8[Random.Int(8)];
		
		Ballistica route = new Ballistica( pos+direction, target, Ballistica.PROJECTILE);
		if (route.dist == 0){
			teleport();
			return;
		}
		int cell = route.collisionPos;

		//can't occupy the same cell as another char, so move back one.
		if (Actor.findChar( cell ) != null && cell != this.pos)
			cell = route.path.get(route.dist-1);

		if (Dungeon.level.avoid[ cell ]){
			ArrayList<Integer> candidates = new ArrayList<>();
			for (int n : PathFinder.NEIGHBOURS8) {
				cell = route.collisionPos + n;
				if (Dungeon.level.passable[cell] && Actor.findChar( cell ) == null) {
					candidates.add( cell );
				}
			}
			if (candidates.size() > 0)
				cell = Random.element(candidates);
			else {
				teleportCooldown = Random.IntRange(1, 6);
				return;
			}
		}
		
		ScrollOfTeleportation.appear( this, cell );

		teleportCooldown = Random.IntRange(1, 6);
	}
	
	@Override
	public int attackSkill( Char target ) {
		return 20;
	}

	private static final String TELEPORTING_COOLDOWN = "teleportingcooldown";

	@Override
	public void storeInBundle(Bundle bundle) {
		super.storeInBundle(bundle);
		bundle.put(TELEPORTING_COOLDOWN, teleportCooldown);
	}

	@Override
	public void restoreFromBundle(Bundle bundle) {
		super.restoreFromBundle(bundle);
		teleportCooldown = bundle.getInt(TELEPORTING_COOLDOWN);
	}
}
