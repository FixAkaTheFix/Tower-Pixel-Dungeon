package com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers;

import com.shatteredpixel.shatteredpixeldungeon.sprites.TowerCrossbow3Sprite;

public class TowerCrossbow3 extends TowerCrossbow2{

    {
        HP = HT = 80;
        spriteClass = TowerCrossbow3Sprite.class;

        viewDistance = 8;
        baseAttackDelay = 0.5f;
        cost = 1000;
        upgCount=2;
        upgrade1Cost = 1000;
        upgrade2Cost = 1000;
        damageMin = 7;
        damageMax = 10;
    }
}
