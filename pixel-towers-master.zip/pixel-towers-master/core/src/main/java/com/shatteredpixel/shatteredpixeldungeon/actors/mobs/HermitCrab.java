package com.shatteredpixel.shatteredpixeldungeon.actors.mobs;

import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Terror;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.HermitCrabSprite;
import com.watabou.utils.Random;

public class HermitCrab extends Crab {

    {
        spriteClass = HermitCrabSprite.class;

        HP = HT = 15;
        defenseSkill = 5;
        baseSpeed = 0.95f;

        EXP = 0;
        maxLvl = 10;

    }

    @Override
    public int drRoll() {
        return super.drRoll() + Random.NormalIntRange(5, 7);
    }

    @Override
    public void die(Object cause) {
        super.die(cause);
        HermitCrabNoShell hermitCrabNoShell = new HermitCrabNoShell();
        hermitCrabNoShell.pos = pos;
        Buff.affect(hermitCrabNoShell, Terror.class, 10);
        GameScene.add(hermitCrabNoShell);
    }
}
