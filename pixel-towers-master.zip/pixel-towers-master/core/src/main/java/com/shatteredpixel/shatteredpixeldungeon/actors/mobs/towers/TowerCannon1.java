package com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers;

import com.shatteredpixel.shatteredpixeldungeon.Assets;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.effects.CellEmitter;
import com.shatteredpixel.shatteredpixeldungeon.effects.particles.BlastParticle;
import com.shatteredpixel.shatteredpixeldungeon.effects.particles.SmokeParticle;
import com.shatteredpixel.shatteredpixeldungeon.items.Heap;
import com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.TowerCannon1Sprite;
import com.watabou.noosa.audio.Sample;
import com.watabou.utils.PathFinder;

public class TowerCannon1 extends TowerCShooting{

    {
        HP = HT = 30;
        spriteClass = TowerCannon1Sprite.class;

        viewDistance = 6;
        baseAttackDelay = 1.5f;

        cost = 300;
        upgrade1Cost = 300;
        damageMin = 1;
        damageMax = 7;
        upgradeLevel = 3;

    }

    public float damageExplosionMult = 0.5f;

    @Override
    public int attackSkill(Char target) {//Nope, no dodging an explosion at its epicentre((
        return 100;
    }

    @Override
    public boolean attack(Char enemy, float dmgMulti, float dmgBonus, float accMulti) {
        int cell;


        for (int i : PathFinder.NEIGHBOURS8){
            cell = enemy.pos + i;
            if (Actor.findChar(cell)!=null){
                if (Actor.findChar(cell).alignment == Alignment.ALLY){
                    //friends receive 0 damage
                } else Actor.findChar(cell).damage (Math.round(damageRoll()*damageExplosionMult) - enemy.drRoll(),this);//damages foes nearby, with lowered damage
            }
            if (Dungeon.level.heroFOV[enemy.pos+i]) {
                CellEmitter.center(cell).burst(BlastParticle.FACTORY, 30);
                Sample.INSTANCE.play(Assets.Sounds.BLAST);
            }
            if (Dungeon.level.heroFOV[enemy.pos]) {
                CellEmitter.center(enemy.pos).start(SmokeParticle.FACTORY, 0.3f, 8);
                CellEmitter.center(enemy.pos).start(SmokeParticle.FACTORY, 1f, 8);
            }
            if (Dungeon.level.flamable[cell]) {//affects terrain
                Dungeon.level.destroy(cell);
                GameScene.updateMap(cell);
            }
            Heap heap = Dungeon.level.heaps.get(cell);//explodes bombs and affects heaps nearby
            if (heap != null) heap.explode();
        }

        return super.attack(enemy, dmgMulti, dmgBonus, accMulti);
    }


    @Override
    protected boolean canAttack( Char enemy ) {
        return (new Ballistica( pos, enemy.pos, Ballistica.PROJECTILE).collisionPos == enemy.pos||Dungeon.level.distance(enemy.pos, this.pos)<=viewDistance);
    }
}
