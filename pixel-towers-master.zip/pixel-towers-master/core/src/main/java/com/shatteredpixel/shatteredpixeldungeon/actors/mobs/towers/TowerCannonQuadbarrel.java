package com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.effects.CellEmitter;
import com.shatteredpixel.shatteredpixeldungeon.effects.particles.BlastParticle;
import com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.TowerCannonQuadbarrelSprite;
import com.watabou.utils.PathFinder;
import com.watabou.utils.Random;

import java.util.ArrayList;

public class TowerCannonQuadbarrel extends TowerCShooting {

    {
        HP = HT = 100;
        spriteClass = TowerCannonQuadbarrelSprite.class;

        viewDistance = 7;//DPT =32.5*0.66 = 21.45;DPT/C=21,45:1150=0.0187
        baseAttackDelay = 0.6f;

        upgCount = 0;

        cost = 2800;
        upgrade1Cost = 1500;
        damageMin = 10;
        damageMax = 15;

    }

    public float damageExplosionMult = 0.5f;

    @Override
    public int attackSkill(Char target) {//Nope, no dodging an explosion at its epicentre((
        return 100;
    }

    @Override
    public boolean attack(Char enemy, float dmgMulti, float dmgBonus, float accMulti) {

        ArrayList<Integer> chooseCellToBomb = new ArrayList<>();
        for (int i : PathFinder.NEIGHBOURS8) {
            if (Dungeon.level.passable[enemy.pos+i])chooseCellToBomb.add(enemy.pos + i);
        }
        int cell;
        for (int i : PathFinder.NEIGHBOURS5) {
            cell = enemy.pos + i;
            Char ch = Actor.findChar(cell);
            if (ch != null) {
                if (ch.alignment == TowerCannonQuadbarrel.this.alignment) {
                } else if (Actor.findChar(enemy.pos) == ch) {
                } else ch.damage(Math.round(damageRoll() * damageExplosionMult) - enemy.drRoll(), this);//damages foes nearby, with lowered damage
            }
            CellEmitter.floor(cell).burst(BlastParticle.FACTORY, Random.Int(1, 3));
        }

        GameScene.updateFog();
        return super.attack(enemy, dmgMulti, dmgBonus, accMulti);
    }

    @Override
    protected boolean canAttack( Char enemy ) {
        return (new Ballistica( pos, enemy.pos, Ballistica.PROJECTILE).collisionPos == enemy.pos||Dungeon.level.distance(enemy.pos, this.pos)<=viewDistance);
    }
}

