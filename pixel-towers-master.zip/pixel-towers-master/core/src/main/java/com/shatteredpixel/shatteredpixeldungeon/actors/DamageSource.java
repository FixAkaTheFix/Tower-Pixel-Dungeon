package com.shatteredpixel.shatteredpixeldungeon.actors;

import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Electricity;
import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Fire;
import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.ToxicGas;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Burning;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Charm;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Chill;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Corrosion;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Degrade;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Frost;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Hex;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Hunger;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MagicalSleep;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Ooze;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Paralysis;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Poison;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Vulnerable;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Weakness;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.abilities.duelist.ElementalStrike;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.abilities.mage.ElementalBlast;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.abilities.mage.WarpBeacon;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.DM100;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.DMWHead;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Eye;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.GnollTrickster;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.MagicShard;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Shaman;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Warlock;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.YogFist;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers.TowerPylon;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers.TowerWand1;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers.TowerWand2;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers.TowerWand3;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers.TowerWandFireball;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers.TowerWandLightning;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.towers.TowerWandPrismatic;
import com.shatteredpixel.shatteredpixeldungeon.items.bombs.Bomb;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfRetribution;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.exotic.ScrollOfPsionicBlast;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.CursedWand;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfBlastWave;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfDisintegration;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfFireblast;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfFrost;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfLightning;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfLivingEarth;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfMagicMissile;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfPrismaticLight;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfTransfusion;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfWarding;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.DebugBow;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.SpiritBow;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.enchantments.Blazing;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.enchantments.Grim;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.enchantments.Shocking;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.RunicBlade;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.Bolas;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.FishingSpear;
import com.shatteredpixel.shatteredpixeldungeon.levels.traps.DisintegrationTrap;
import com.shatteredpixel.shatteredpixeldungeon.levels.traps.GrimTrap;

import java.util.HashSet;

public class DamageSource {

    public static final HashSet<Class> MAGICAL = new HashSet<>();

    static {
        MAGICAL.add( MagicalSleep.class );
        MAGICAL.add( Charm.class );
        MAGICAL.add( Weakness.class );
        MAGICAL.add( Vulnerable.class );
        MAGICAL.add( Hex.class );
        MAGICAL.add( Degrade.class );

        MAGICAL.add( DisintegrationTrap.class );
        MAGICAL.add( GrimTrap.class );

        MAGICAL.add( Bomb.MagicalBomb.class );

        MAGICAL.add( ScrollOfRetribution.class );
        MAGICAL.add( ScrollOfPsionicBlast.class );
        MAGICAL.add( ScrollOfTeleportation.class );

        MAGICAL.add( ElementalBlast.class );
        MAGICAL.add( CursedWand.class );
        MAGICAL.add( WandOfBlastWave.class );
        MAGICAL.add( WandOfDisintegration.class );
        MAGICAL.add( WandOfFireblast.class );
        MAGICAL.add( WandOfFrost.class );
        MAGICAL.add( WandOfLightning.class );
        MAGICAL.add( WandOfLivingEarth.class );
        MAGICAL.add( WandOfMagicMissile.class );
        MAGICAL.add( WandOfPrismaticLight.class );
        MAGICAL.add( WandOfTransfusion.class );
        MAGICAL.add( WandOfWarding.Ward.class );
        MAGICAL.add(RunicBlade.class);

        MAGICAL.add( ElementalStrike.class );
        MAGICAL.add( Blazing.class );
        MAGICAL.add( Shocking.class );
        MAGICAL.add( Grim.class );

        MAGICAL.add( WarpBeacon.class );

        MAGICAL.add( DM100.LightningBolt.class );
        MAGICAL.add( DMWHead.LightningBolt.class );
        MAGICAL.add( Shaman.EarthenBolt.class );
        MAGICAL.add( Warlock.DarkBolt.class );
        MAGICAL.add( Eye.DeathGaze.class );
        MAGICAL.add( YogFist.BrightFist.LightBeam.class );
        MAGICAL.add( YogFist.DarkFist.DarkBolt.class );
        MAGICAL.add(MagicShard.class);

        MAGICAL.add(TowerWand1.class);
        MAGICAL.add(TowerWand2.class);
        MAGICAL.add(TowerWand3.class);
        MAGICAL.add(TowerWandLightning.class);
        MAGICAL.add(TowerWandFireball.class);
        MAGICAL.add(TowerWandPrismatic.class);

    }

    public static final HashSet<Class> DRIGNORING = new HashSet<>();

    static {
        DRIGNORING.add(TowerWand1.class);
        DRIGNORING.add(TowerWand2.class);
        DRIGNORING.add(TowerWand3.class);

        DRIGNORING.add(WandOfMagicMissile.class);
    }

    public static final HashSet<Class> PHYSICAL = new HashSet<>();
    static {
       //OTHER STUFF PHYSICAL.add etc
        //TODO: MAKE THIS GARBAGE INCLUDE ALL OF THE MELEE WEAPONRY, AND ENEMY ATTACKS
    }

    public static final HashSet<Class> SHIELDIGNORING = new HashSet<>();
    static {
        SHIELDIGNORING.add(Hunger.class);
    }

    public static final HashSet<Class> PROJECTILE = new HashSet<>();
    static {
        PROJECTILE.add(DebugBow.class);
        PROJECTILE.add(SpiritBow.class);

        //PROJECTILE.add(WandOfPebbles.class);
        PROJECTILE.add(GnollTrickster.class);


        PROJECTILE.add(Bolas.class);
        PROJECTILE.add(FishingSpear.class);

    }


    public static final HashSet<Class> ELEMENTAL = new HashSet<>();
    static {
        ELEMENTAL.add( Burning.class );
        ELEMENTAL.add( Fire.class );
        ELEMENTAL.add( Chill.class );
        ELEMENTAL.add( Frost.class );
        ELEMENTAL.add( Ooze.class );
        ELEMENTAL.add( Paralysis.class );
        ELEMENTAL.add( Poison.class );
        ELEMENTAL.add( Corrosion.class );
        ELEMENTAL.add( ToxicGas.class );
        ELEMENTAL.add( Electricity.class );
        ELEMENTAL.add( WandOfFireblast.class );
        ELEMENTAL.add( Blazing.class);
        ELEMENTAL.add( WandOfFrost.class );
        ELEMENTAL.add( Shocking.class );
        ELEMENTAL.add( DMWHead.LightningBolt.class );
        ELEMENTAL.add( DM100.LightningBolt.class );
        ELEMENTAL.add( WandOfLightning.class );


    }
    public static final HashSet<Class> FIRE = new HashSet<>();
    static {
        FIRE.add( Burning.class );
        FIRE.add( WandOfFireblast.class );
        FIRE.add( Blazing.class);
        FIRE.add( Fire.class );
    }
    public static final HashSet<Class> ICE = new HashSet<>();
    static {
        ICE.add( Chill.class );
        ICE.add( Frost.class );
        ICE.add( WandOfFrost.class );
    }
    public static final HashSet<Class> LIGHTNING = new HashSet<>();
    static {
        LIGHTNING.add( Shocking.class );
        LIGHTNING.add( Electricity.class );
        LIGHTNING.add( DMWHead.LightningBolt.class );
        LIGHTNING.add( DM100.LightningBolt.class );
        LIGHTNING.add( WandOfLightning.class );
        LIGHTNING.add( TowerPylon.LightningBolt.class );
    }
    public static final HashSet<Class> POISON = new HashSet<>();
    static {
        POISON.add(Poison.class);
        POISON.add(ToxicGas.class);
        POISON.add(Corrosion.class);
    }

}
