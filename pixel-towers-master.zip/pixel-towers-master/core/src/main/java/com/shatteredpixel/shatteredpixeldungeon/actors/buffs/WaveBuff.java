package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.levels.Arena;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.ui.BuffIndicator;

public class WaveBuff extends Buff {

    {
        type = buffType.NEUTRAL;
        announced = true;
    }

    @Override
    public String desc() {
        return Messages.get(this, "desc", Dungeon.level.wave, ((Arena)Dungeon.level).maxWaves);
    }

    @Override
    public String heroMessage() {
        return "";
    }

    @Override
    public int icon() {
        return BuffIndicator.WAVE;
    }
}