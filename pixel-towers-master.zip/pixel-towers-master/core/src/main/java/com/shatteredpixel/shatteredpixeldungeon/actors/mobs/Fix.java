package com.shatteredpixel.shatteredpixeldungeon.actors.mobs;

public class Fix extends Mob{




}
