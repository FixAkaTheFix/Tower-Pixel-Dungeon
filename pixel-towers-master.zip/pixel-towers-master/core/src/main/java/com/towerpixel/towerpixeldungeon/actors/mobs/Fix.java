package com.towerpixel.towerpixeldungeon.actors.mobs;

public class Fix extends Mob{




}
