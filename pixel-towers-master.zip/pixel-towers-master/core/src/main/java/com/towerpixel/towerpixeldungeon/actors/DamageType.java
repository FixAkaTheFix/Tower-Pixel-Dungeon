package com.towerpixel.towerpixeldungeon.actors;

public enum DamageType {
    PHYSICAL,
    MAGICAL,
    ELEMENTAL,
    LIGHTNING,
    ICE,
    FIRE,
    SHIELDIGNORING,
    PROJECTILE,
    POISON,
    PURE
}
