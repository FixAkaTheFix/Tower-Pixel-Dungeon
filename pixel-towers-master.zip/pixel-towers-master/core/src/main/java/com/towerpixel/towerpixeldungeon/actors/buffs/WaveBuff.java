package com.towerpixel.towerpixeldungeon.actors.buffs;

import com.towerpixel.towerpixeldungeon.Dungeon;
import com.towerpixel.towerpixeldungeon.levels.Arena;
import com.towerpixel.towerpixeldungeon.messages.Messages;
import com.towerpixel.towerpixeldungeon.ui.BuffIndicator;

public class WaveBuff extends Buff {

    {
        type = buffType.NEUTRAL;
        announced = true;
    }

    @Override
    public String desc() {
        return Messages.get(this, "desc", Dungeon.level.wave, ((Arena)Dungeon.level).maxWaves);
    }

    @Override
    public String heroMessage() {
        return "";
    }

    @Override
    public int icon() {
        return BuffIndicator.WAVE;
    }
}